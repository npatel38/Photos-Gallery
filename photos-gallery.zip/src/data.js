const getData = () => {
  let data = [
    {
      src: `https://source.unsplash.com/random/500x500?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x400?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x700?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x250?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x800?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x500?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x400?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x700?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x250?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x800?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x400?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x700?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    },
    {
      src: `https://source.unsplash.com/random/500x250?sig=${Math.floor(
        Math.random() * 999
      )}`,
      height: 256,
      width: 256,
      author: "Awesome"
    }
  ];
  return data;
};

export default getData;
