import React from "react";

function Header() {
  return (
    <header>
      <h1> Image Gallery </h1>
    </header>
  );
}

export default Header;
